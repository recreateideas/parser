
import React,{ Component,PureComponent } from 'react';
import logo from './logo.svg';
import './App.css';

class Game extends Component {
  locationMap = [
    [0,0],
    [1,0],
    [2,0],
    [0,1],
    [1,1],
    [2,1],
    [0,2],
    [1,2],
    [2,2]
  ]
  constructor(props){// to assign a state to a component I need to call a constructor
    super(props); //need to first call the cunstructor of the parent element
    this.state = { // the state is an object
      history:[{
        squares: Array(9).fill(null),
        location: Array(2).fill(null),
      }],
      stepNumber: 0,
      active: null,
      xIsNext:true,
      moves: null,
      winner: null,
      current: null,
      status: null
    };
  }

  handleClick(i){
    const history = this.state.history.slice(0,this.state.stepNumber + 1);
    const current = history[history.length -1];
    const squares = current.squares.slice(); //slice creates a copy of the orignal array
    if (calculateWinner(squares) || squares[i]){ //if there is a winner or thecurrent button has alreadyy been clicked
      return;
    }
    squares[i] = this.state.xIsNext ? 'X' : 'O';
    this.setState({
      history: history.concat([
        {
          squares: squares,
          location: this.locationMap[i],
        }
      ]),
      stepNumber: history.length,
      xIsNext: !this.state.xIsNext
    });
  }

  jumpTo(step){
    this.setState({
      stepNumber: step,
      xIsNext: (step % 2) === 0
    });
  }

  handleSort(){
    console.log(this.state.moves);
  }

  fun(move){
    console.log(move);
    this.setState({
      moves: move
    });
  }

  displayButtons(){

  }

  render(){
    const history = this.state.history;
    const current = history[this.state.stepNumber];
    const winner = calculateWinner(current.squares);
    let moves = history.map((step,move) =>{ //Display the location for each move in the format (col, row) in the move history list. CHECK
      const desc = move ? 'Go to move #' + move + ', location: '+history[move].location[0]+','+history[move].location[1]: 'Go to game start'; //It’s strongly recommended that you assign proper keys whenever you build dynamic lists.
      if (move === this.state.stepNumber) {
        return (
          <li key={move}>
            <button onClick={()=> {this.jumpTo(move)}} className='bold'>{desc}</button>
          </li>
        );
      }
      else {
        return (
          <li key={move}>
            <button onClick={()=> {this.jumpTo(move)}}>{desc}</button>
          </li>
        );
      }
    });
    let status;
    if (winner){
      status = 'The winner is: '+winner;
    }
    else{
      status = 'Next player: '+ (this.state.xIsNext ? 'X' : 'O');
    }
    return (
      <div>
        <div>
          <Header />
        </div>
        <div className='game'>
          <div className='game-board'>
            <Board
              squares={current.squares}
              onClick ={(i) => this.handleClick(i)}
            />
          </div>

          <div className='game-info'>
            <div>{status}</div>
            <div className='sort'>
              <Button
                onClick = {() => this.handleSort()}
                className='sort-btn'
              />
            </div>
            <ol>{moves}</ol>
          </div>
        </div>
      </div>
    );
  }
}

class Board extends PureComponent { //PureComponent updates only if the state or props change, higher performance
  renderSquare(i){
    return ( // we pass props down to the child element as properties
      <Square
        value={this.props.squares[i]}
        onClick={() => this.props.onClick(i)}
        key={i}
      />)
    }
    createTable(){ //creates a DOM structure and stores it in variable table
      let table = [];
      let x = 0;
      while(x<7){
        let children = [];
        for(let y=x+0;y<x+3;y++){ //children element have to be created first
          children.push(this.renderSquare(y));
        }
        table.push(<div className='board-row' key={x}>{children}</div>); //create parent elements by inserting children
        x = x+ 3;
      }
      return table;
    }
    render(){
      return(
        <div>
          {this.createTable()}
        </div>
      );
    }
  }


  function Square(props) { //functional component, used if all we need to do is to render props. It contains only a render method
    return (
      <button className='square' onClick={props.onClick}>
        {props.value}
      </button>
    )
  }

  class Button extends Component {
    constructor(props){
      super(props);
      this.state = {
        pressed: false,
        ascending: true,
        onClick: props.onClick //this.props.onClick
      };
    }

    onClick(){
      this.setState({
        ascending : !this.state.ascending
      });
      this.state.onClick();
    }

    render(){
      const innerText = this.state.ascending ? 'ascending' : 'descending';
      return (
        <button className='sort-btn' onClick={this.onClick.bind(this)}>{innerText}</button>
      );
    }
  }


  //===================================================


  function Header(){
    return (
      <div>
        <img src={logo} className="App-logo" alt="logo" />
        <h1 className="App-title">Tic Tac Toe</h1>
      </div>
    )
  }

  function calculateWinner(squares){
    const lines = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6],
    ];
    for(let i = 0; i<lines.length;i++){
      const [a,b,c] = lines[i];
      if (squares[a] && squares[a] === squares[b] && squares[a] === squares[c]) {
        return squares[a];
      }
    }
    return null;
  }

  /*ReactDOM.render(
  <Game />, document.getElementById('root')
)*/
export default Game;
